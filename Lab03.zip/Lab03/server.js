const connect = require('connect');
const { log } = require('console');
const url = require('url');

const app = connect();

app.use((req, res) => {
  const parsedUrl = url.parse(req.url, true); 
  const query = parsedUrl.query; 
  const method = query.method
  const x = Number(query.x)
  const y = Number(query.y)
  const sign = {
    add:"+",
    subtract : "-",
    multiply : "*",
    divide : "/"
}
  switch (method) {
    case "add":
        ans = x + y
        break;
    case "subtract":
        ans = x - y
        break;
    case "multiply":
        ans = x * y
        break;
    case "divide":
        ans = x / y
        break;
  
    default:
        res.end("Please pass a correct method")
        ans = null
        break;
  }
  console.log(`${x} ${sign[method]} ${y} = ${ans}`);
  res.end(`${x} ${sign[method]} ${y} = ${ans}`);
  res.writeHead(200);
  
});

app.listen(3000, () => console.log('Server listening on port 3000'));
